<?php
ini_set("post_max_size", "1G");
ini_set("upload_max_filesize", "1G");
ini_set("memory_limit", "3G");
ini_set("max_input_time",  7000);
ini_set("max_execution_time",  7000);

require_once("config2.php");
$conn = connect();

  $video = $_FILES["video_file"];
  $title = $_POST["title"];
  $passcode = $_POST["passcode"];

  $sql = "SELECT passcode FROM users WHERE passcode = '$passcode'";
  $result = $conn->query($sql);
  $result = $result->fetch();

  if(!$result){
    die(json_encode(array("status" => 0, "output"=>"The passcode does not exist. Please create the passcode and try again")));
  }

  //checking if name exixts in db
  $sql = "SELECT video_id FROM admin_videos WHERE title = '$title'";
  $result = $conn->query($sql);
  $result = $result->fetch();

  if($result){
    echo json_encode(array("status" => 0, "output"=>"The video title exists in the database. Please change it and try again"));
  }else{
    $valid_extensions = array("mp4", "avi", "mkv", "3gp", "mpg", "MPG", "MP4", "ogg", "OGG", "mpeg", "MPEG", "flv", "FLV", "AVI");
  	$video_name = $video["name"];
  	$tmp_name = $video["tmp_name"];
  	$file_extension = strtolower(pathinfo($video_name, PATHINFO_EXTENSION));
  	$outputfile = "vid".rand(100000, 1000000000).rand(100000, 1000000000).".mp4";

  	if(in_array($file_extension, $valid_extensions)){
  		$video_name = rand(10000, 1000000).$video_name;
  		if(move_uploaded_file($tmp_name, "../admin/videos/".$outputfile)){
        $sql = "INSERT INTO admin_videos(title, passcode, database_id, date) VALUES('$title', '$passcode', '$outputfile', now())";
        $conn->query($sql);
        echo json_encode(array('status' => 1, 'output'=> array("title"=>$title, "database_id"=>$outputfile)));
  		}else{
  			echo json_encode(array('status' => 0, 'output'=> 'File Upload Error: Please reduce the file size and try again'));
  		}
  	}else{
  		echo json_encode(array('status' => 0, 'output'=> 'File Upload Error: The uploded file type is not surported'));
  	}
  }

?>
