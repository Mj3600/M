<?php
  require_once("config2.php");
  $conn = connect();

  $sql = "SELECT * FROM merged_videos";

  $result = $conn->query($sql);
  $result = $result->fetchAll();

  echo json_encode($result);
?>
