<?php
  require_once("config2.php");
  session_start();

  echo $_SESSION["user"];
?>
