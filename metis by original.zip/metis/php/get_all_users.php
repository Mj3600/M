<?php
  require_once("config2.php");
  $conn = connect();

  $sql = "SELECT * FROM users, user_details WHERE users.passcode = user_details.passcode";

  $result = $conn->query($sql);
  $result = $result->fetchAll();

  echo json_encode($result);
?>
