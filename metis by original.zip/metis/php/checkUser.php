<?php
  session_start();

  if(isset($_SESSION["user"]) and $_SESSION["user"] == "User"){
    echo $_SESSION["passcode"];
  }else{
    echo false;
  }
?>
