<?php
  require_once("config2.php");
  $conn = connect();

  $video = $_POST["video"];

  $sql = "SELECT * FROM merged_videos, user_details WHERE merged_videos.passcode = user_details.passcode AND merged_videos.database_id = '$video'";
  $result = $conn->query($sql);
  $result = $result->fetch();

  echo json_encode($result);
?>
