<?php
  require_once("config2.php");
  $conn = connect();

  $video = $_POST["video"];

  $sql = "SELECT * FROM merged_videos WHERE database_id = '$video'";

  $result = $conn->query($sql);
  $result = $result->fetch();

  if($result){
    echo true;
  }else{
    echo false;
  }
?>
