<?php
  require_once("config.php");
  session_start();

  $conn = connect();

  $username = $_POST["username"];
  $password = $_POST["password"];

  $sql = "INSERT INTO users(username, password, type, trials, status) VALUES('$username', '$password', 'User', 0, 'unreg')";

  if($conn -> query($sql)){
    echo json_encode(array("username"=>$username, "password"=>$password));
  }else{
    echo false;
  }
?>
