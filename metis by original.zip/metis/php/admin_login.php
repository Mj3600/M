<?php
  require_once("config2.php");
  session_start();

  $conn = connect();

  $username = $_POST["username"];
  $password = $_POST["password"];

  $sql = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";

  $result =  $conn->query($sql);
  $result = $result->fetch();

  if($result){
    echo json_encode(array("status"=>true, "outcome"=>"admin"));
    $_SESSION["user"] = "admin";
  }else{
    $result = array("status"=>false, "outcome"=>"Invalid Login Details");
    echo json_encode($result);
  }
?>
