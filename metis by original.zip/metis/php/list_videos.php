<?php
  $files = glob('../videos/*.mp4');
  $filenames = array();

  foreach($files as $file){
    $filename = substr($file, 10);
    array_push($filenames, $filename);
  }

  echo json_encode($filenames);
?>
