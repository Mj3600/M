<?php
  require_once("config2.php");
  $conn = connect();

  $passcode = $_POST["passcode"];

  $sql = "DELETE FROM users WHERE passcode = '$passcode'";
  $conn->query($sql);

  $sql = "DELETE FROM merged_videos WHERE passcode = '$passcode'";
  $conn->query($sql);

  $sql = "DELETE FROM admin_videos WHERE passcode = '$passcode'";
  $conn->query($sql);

  echo true;
?>
