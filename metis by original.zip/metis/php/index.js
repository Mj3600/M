const setCookie = (cname, cvalue) => {
  document.cookie = `${cname} = ${cvalue}`
}

const getCookie = (cname) => {
  var name = cname + "=";
  var ca = document.cookie.split(";");

  for(var i = 0; i < ca.length; i++){
    var c = ca[i];

    while(c.charAt(0) == ' '){
      c = c.substring(1);
    }

    if(c.indexOf(name) == 0){
      return c.substring(name.length, c.length)
    }
  }

  return ""
}

const checkfields = () => {
  var empty = false

  $(".form-input").each(function(){
    if($(this).val() == ""){
      $(this).css({"border":"1px solid red"})
      empty = true
    }
  })

  return empty
}

const highlight_empty = () => {
  $(".form-input").each(function(){
    $(this).change(function(){
      if($(this).val() == ""){
        $(this).css({"border":"1px solid red"})
      }else{
        $(this).css({"border":"1px solid blue"})
      }
    })
  })
}

const save = (object) => {
  if(!checkfields()){
    $.post("php/login.php", object, function(result){
        var output = JSON.parse(result)
        var status = output["status"]
        console.log(output)

        if(status){
          var user = output["outcome"]
          if(user == "1"){
            showModal("success", "Admin - Login successfull", "succ52563", function(){
              hideModal()
              window.location.href = "createUser.html"
            })
          }else if(user == "2"){
            var times = output["times"]
            showModal("success", "User - Login successfull", "suce762832bs", function(){
              hideModal()
              if(times == "reg"){
                window.location.href = "upload.html"
              }else if(times == "unreg"){
                window.location.href="registration.html"
              }
            })
          }

        }else{
          var message = output["outcome"]
          $(".message").text(message)
        }
    })
  }else{
    $(".message").text("Some fields are empty. Enter all the fields to proceed")
  }
}

$(document).ready(function(){
  highlight_empty()

  $(document).on("click", ".login_button", function(e){
    e.preventDefault()

    var user_object = {
      'username' : $(".username").val(),
      'password' : $(".password").val()
    }

    save(user_object)
  })
})
