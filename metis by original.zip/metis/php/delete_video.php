<?php
  require_once("config.php");
  $conn = connect();

  $database_name = $_POST["database_name"];
  unlink("../merged_videos/".$database_name);

  $sql = "DELETE FROM videos WHERE database_name = '$database_name'";

  if($conn->query($sql)){
    echo true;
  }else{
    echo false;
  }
?>
