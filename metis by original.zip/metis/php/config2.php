<?php
    //declare the database connection variables

    define("DSN", "mysql:dbName=technige_metis");
    define("USERNAME", "technige_metis");
    define("PASSWORD", "metis@maven");

    //function to connect to database
    function connect(){
        $conn = new PDO(DSN, USERNAME, PASSWORD);
        $conn->setAttribute(PDO::ATTR_PERSISTENT, true);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $sql = "USE technige_metis";
        $conn->query($sql);

        return $conn;
    }

    function disconnect($conn){
        $conn = "";
    }


?>
