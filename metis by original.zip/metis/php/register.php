<?php
  require_once("config2.php");
  session_start();

  $conn = connect();

  $name = $_POST["name"];
  $speciality = $_POST["speciality"];
  $qualification = $_POST["qualification"];
  $clinic_name = $_POST["clinic_name"];
  $passcode = $_POST["passcode"];

  $sql = "SELECT * FROM user_details WHERE passcode = '$passcode'";
  $result = $conn->query($sql);
  $result = $result->fetchAll();

  if($result){
    $sql = "UPDATE user_details SET name = '$name', speciality = '$speciality', qualification = '$qualification', clinic = '$clinic_name' WHERE passcode = '$passcode'";
    $conn->query($sql);
    echo true;
  }else{
    $sql = "INSERT INTO user_details(name, speciality, qualification, clinic, passcode) VALUES('$name', '$speciality', '$qualification', '$clinic_name', '$passcode')";
    if($conn->query($sql)){
      $sql = "UPDATE users SET reg = 'true' WHERE passcode = '$passcode'";
      $conn->query($sql);
      echo true;
    }
  }
?>
