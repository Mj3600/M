<?php
    require_once("config2.php");
    $conn = connect();
    $content = "";

    try{
    //writing on video
    $passcode = $_POST["passcode"];
    $temp_name = $_POST["temp_name"];
    $edited =  "upload".rand(100000, 1000000000).rand(100000, 1000000000).rand(100000, 1000000000).".mp4";

    $sql = "SELECT upload_limit, no_uploaded FROM users WHERE passcode = '$passcode'";
    $result = $conn->query($sql);
    $result = $result->fetch();

    if($result["no_uploaded"] >= $result["upload_limit"]){
      die(json_encode(array("status"=>false, "output"=>"You have exceeded the maximum number of Uploads. Please contact admin for new passcode")));
    }

    $sql = "SELECT * FROM user_details WHERE passcode = '$passcode'";
    $result = $conn->query($sql);
    $result = $result->fetch();

    $name = $result["name"];
    $speciality = $result["speciality"];
    $qualification = $result["qualification"];
    $hospital = $result["clinic"];
    $second = $speciality."({$qualification})";

    $name = strtoupper($name);
    $speciality = strtoupper($speciality);
    $qualification = strtoupper($qualification);
    $hospital = strtoupper($hospital);
    $second = strtoupper($second);

    $command = "ffmpeg -i ../unprocessed/{$temp_name} -vf \"[in]drawtext=fontsize=47:fontcolor=white:fontfile='../fonts/Nunito/nunito.ttf':text='{$name}':x=10:y=(h) - 120, drawtext=fontsize=35:fontcolor=white:fontfile='../fonts/Amiri/amiri.ttf':text='{$second}':x=10:y=(h) - 80, drawtext=fontsize=30:fontcolor=white:fontfile='../fonts/Amiri/amiri.ttf':text='{$hospital}':x=10:y=(h-40)[out]\" -y ../unprocessed/{$edited}";
    system($command);
    unlink("../unprocessed/{$temp_name}");

    $video_1 = $_POST["video1"];
    $video_2 = $edited;

    try{

      //generating intermediate files
      $intermediate1 =  "intermediate".rand(100000, 1000000000).rand(100000, 1000000000).".mpg";
      $command = "ffmpeg -i ../unprocessed/{$edited} -qscale 0 -r 25 ../unprocessed/{$intermediate1}";
      system($command);
      unlink("../unprocessed/{$edited}");

      $intermediate2 =  "intermediate".rand(100000, 1000000000).rand(100000, 1000000000).".mpg";
      $command = "ffmpeg -i ../admin/videos/{$video_1} -qscale 0 -r 25 ../unprocessed/{$intermediate2}";
      system($command);

      $outputfile_temp = "upload".rand(100000, 1000000000).rand(100000, 1000000000).rand(100000, 1000000000).".mp4";

      $command = "ffmpeg -i \"concat:../unprocessed/{$intermediate1}|../unprocessed/{$intermediate2}\" -c copy ../merged_videos/{$outputfile_temp}";
      system($command);
      unlink("../unprocessed/{$intermediate1}");
      unlink("../unprocessed/{$intermediate2}");

      $outputfile = "upload".rand(100000, 1000000000).rand(100000, 1000000000).rand(100000, 1000000000).".mp4";
      $command = "ffmpeg -i ../merged_videos/{$outputfile_temp} ../merged_videos/{$outputfile}";
      system($command);
      unlink("../merged_videos/{$outputfile_temp}");

      $sql = "INSERT INTO merged_videos(passcode, database_id, date_uploaded, expiry_date) VALUES('$passcode', '$outputfile', now(), now())";
      $conn->query($sql);

      $sql = "UPDATE users SET no_uploaded = no_uploaded + 1 WHERE passcode = '$passcode'";

      $conn->query($sql);

      echo json_encode(array("status"=>true, "output"=>$outputfile));

    }catch(Exception $e){
      echo $e;
    }

    }catch(Exception $e){
      echo $e;
    }
?>
