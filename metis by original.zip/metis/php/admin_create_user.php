<?php
  require_once("config2.php");
  session_start();

  $conn = connect();

  $passcode = $_POST["passcode"];
  $limit = $_POST["limit"];

  $sql = "SELECT * FROM users WHERE passcode = '$passcode'";
  $result = $conn->query($sql);
  $result = $result->fetch();

  if($result){
    echo json_encode(array("status"=>false, "output"=>"This passcode already exists. Delete the existing one or Create another"));
  }else{
    $sql = "INSERT INTO users(passcode, reg_date, upload_limit, no_uploaded, status, reg) VALUES('$passcode', now(), $limit, 0, 'active', 'false')";

    if($conn -> query($sql)){
      echo json_encode(array("status"=>true, "output"=>array("passcode"=>$passcode, "limit"=>$limit)));
    }else{
      echo false;
    }
  }
?>
