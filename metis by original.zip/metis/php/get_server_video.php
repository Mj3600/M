<?php
  require_once("config2.php");
  $conn = connect();

  $passcode = $_POST["passcode"];
  $sql = "SELECT * FROM admin_videos WHERE passcode = '$passcode'";

  $result = $conn->query($sql);
  $result = $result->fetchAll();

  echo json_encode($result);
?>
