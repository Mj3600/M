<?php
ini_set("post_max_size", "100M");
ini_set("upload_max_filesize", "100M");
ini_set("memory_limit", "3G");
ini_set("max_input_time",  7000);
ini_set("max_execution_time",  7000);

	$video = $_FILES["video_file"];

	if($video["size"] > 100000000){
		die(json_encode(array('status' => 0, 'result'=> 'File Upload Error: Please reduce the file size and try again')));
	}

	$valid_extensions = array("mp4", "avi", "mkv", "3gp", "mpg", "MPG", "MP4", "ogg", "OGG", "mpeg", "MPEG", "flv", "FLV", "AVI");
	$video_name = $video["name"];
	$tmp_name = $video["tmp_name"];
	$file_extension = strtolower(pathinfo($video_name, PATHINFO_EXTENSION));
	$outputfile = "upload".rand(100000, 1000000000).rand(100000, 1000000000).".mp4";

	if(in_array($file_extension, $valid_extensions)){
		$video_name = rand(10000, 1000000).$video_name;
		if(move_uploaded_file($tmp_name, "../unprocessed/".$outputfile)){
			echo json_encode(array('status' => 1, 'result'=> $outputfile));
		}else{
			echo json_encode(array('status' => 0, 'result'=> 'File Upload Error: Large file size. Please reduce the file size to < 100MB and try again'));
		}
	}else{
		echo json_encode(array('status' => 0, 'result'=> 'File Upload Error: The uploded file type is not surported'));
	}
?>
