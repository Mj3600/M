<?php
  require_once("config.php");

  $conn = connect();

  $order = $_POST["order"];


  $sql = "SELECT * FROM user_details, videos WHERE user_details.user_id = videos.user_id ORDER BY '$order' DESC";

  $result = $conn->query($sql);

  $result = $result->fetchAll();

  echo json_encode($result);
 ?>
