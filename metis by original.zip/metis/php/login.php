<?php
  require_once("config2.php");
  session_start();

  $conn = connect();

  $passcode = $_POST["passcode"];

  $sql = "SELECT * FROM users WHERE passcode = '$passcode'";

  $result =  $conn->query($sql);
  $result = $result->fetch();

  if($result){
    echo json_encode(array("status"=>true, "outcome"=>array("passcode"=>$result["passcode"], "reg"=>$result["reg"])));
    $_SESSION["user"] = "User";
    $_SESSION["passcode"] = $result["passcode"];
  }else{
    $result = array("status"=>false, "outcome"=>"Invalid Login Details");
    echo json_encode($result);
  }
?>
