<?php
  require_once("config.php");
  $conn = connect();

  $user_id = $_POST["user_id"];
  $temp_name = $_POST["temp_name"];
  $db_vid_name = $_POST["video_name"];
  $video_name =  "upload".rand(100000, 1000000000).rand(100000, 1000000000).rand(100000, 1000000000).".mp4";

  //getting the posters record
  $sql = "SELECT * FROM user_details WHERE user_id = '$user_id'";
  $result = $conn->query($sql);
  $result = $result->fetch();

  $name = $result["name"];
  $speciality = $result["speciality"];
  $qualification = $result["qualification"];
  $hospital = $result["hospital"];

  $second = $speciality."({$qualification})";

  //writing name on the video
  try{
    //$command = "C:/ffmpeg/bin/ffmpeg -i ../unprocessed/{$temp_name} -c:v libx264 ../unprocessed/temp/{$temp_name}";
    //system($command);

    $command = "C:/ffmpeg/bin/ffmpeg -i ../unprocessed/{$temp_name} -vf \"[in]drawtext=fontsize=28:fontcolor=blue:fontfile='../fonts/Amiri/amiri.ttf':text='{$name}':x=10:y=(h) - 65, drawtext=fontsize=20:fontcolor=Red:fontfile='../fonts/Nunito/nunito.ttf':text='{$second}':x=10:y=(h) - 40, drawtext=fontsize=18:fontcolor=Green:fontfile='../fonts/Nunito/nunito.ttf':text='{$hospital}':x=10:y=(h-25)[out]\" -y ../videos/{$video_name}";
    system($command);
    unlink("../unprocessed/{$temp_name}");
    //unlink("../unprocessed/temp/{$temp_name}");

    $sql = "INSERT INTO videos(user_id, name, date, database_name, contributors) VALUES($user_id, '$db_vid_name', now(), '$video_name', ' ')";
    $conn->query($sql);

    $sql = "UPDATE users SET trials = trials + 1 WHERE user_id = '$user_id'";
    $conn->query($sql);

    echo $video_name;
  }catch(Exception $e){
    echo false;
  }
?>
