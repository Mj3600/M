<?php
  require_once("config2.php");

  $conn = connect();
  $database_id = $_POST["database_id"];

  echo $database_id;

  $sql = "DELETE FROM admin_videos WHERE database_id = '$database_id'";
  $conn->query($sql);

  unlink('../admin/videos/'.$database_id);

  echo true;
?>
