const checkfields = () => {
  var empty = false

  $(".form-input").each(function(){
    if($(this).val() == ""){
      $(this).css({"border":"1px solid red"})
      empty = true
    }
  })

  return empty
}

const highlight_empty = () => {
  $(".form-input").each(function(){
    $(this).change(function(){
      if($(this).val() == ""){
        $(this).css({"border":"1px solid red"})
      }else{
        $(this).css({"border":"1px solid blue"})
      }
    })
  })
}

const save = (object) => {
  if(!checkfields()){
    $.post("php/login.php", object, function(result){
        console.log(result)
        var output = JSON.parse(result)
        var status = output["status"]
        var passcode = output["outcome"]["passcode"]
        var reg = output["outcome"]["reg"]
        if(status){
            showModal("success", "User - Login successfull", "succ52563", function(){
              hideModal()
                window.location.href = "registration.html";
            })
        }else{
          var message = output["outcome"]
          $(".message").text(message)
        }
    })
  }else{
    $(".message").text("Some fields are empty. Enter all the fields to proceed")
  }
}

$(document).ready(function(){
  highlight_empty()

  $(document).on("click", ".login_button", function(e){
    e.preventDefault()

    var user_object = {
      'passcode' : $(".passcode").val()
    }

    save(user_object)
  })
})
