const checkUser = () => {
  let promise = new Promise((accept, reject = function(){}) => {
    $.post("php/checkUser.php", function(result){
      console.log(result)
      if(result != ""){
        let passcode = result
        accept(passcode)
      }else{
        showModal("error", "You are not logged in. Please Log in", "erro3783", function(){
          hideModal();
          window.location.href = "index.html"
        })
      }
    })
  })
  return promise
}

checkUser().then(function(){

})

const default_function = () => {
  $(".prev_video").hide()
  $(".done").hide()
  $(".progress-bar").hide()
}

const display_preview = () => {
  $(".prev_video").show()
  $(".done").show()
  $(".input").hide()
  $(".record").hide()
}

$(document).ready(function(){
  default_function()

  $(document).on('click', '.select_video', function(e){
    e.preventDefault()
    $(".video_file").click()
  })

  $(document).on('click', '.done', function(e){
    e.preventDefault()
    window.location.href="collections.html"
  })

  $(document).on('click', '.record_video', function(e){
    e.preventDefault()
    window.location.href="record.html"
  })

  $(document).on("change", ".video_file", function(){
    let val = $(".video_file").val()
    $(".video_name").val(val)
    $(".record").hide()
    $(".progress-bar").show()
    $(".select_video").attr("disabled", "disabled")
		$(".submit_file").click();
	})

  $(document).on("submit", ".upload_video", function(e){
		e.preventDefault();

		$.ajax({
    xhr: function(){
      var xhr = new window.XMLHttpRequest();
      xhr.upload.addEventListener("progress", function(evt){
        if(evt.lengthComputable){
          var percentComplete = (evt.loaded / evt.total) * 100
          $(".progress").css({"width":percentComplete+"%"})
          $(".progress-text").text(Math.floor(percentComplete)+"%")
        }
      }, false)
      return xhr
    },
		url: "php/upload_raw.php",
		type: "POST",
		contentType: false,
		cache: false,
		processData:false,
		data: new FormData(this),
		success: function(output){
			console.log(output)
			var result = JSON.parse(output);
			var status = result.status;
			var message = result.result;

			if(status == "1"){
        display_preview()
        let html = `<video class="prev_video" controls>
                      <source class="source" src="unprocessed/${message}" type="video/mp4">
                    </video>`
				$(".preview").append(html);
        localStorage["video"] = message

			}else{
				showModal("error", message, "uploadFileError", function(){
					hideModal();
					$(".video_name").val = "";
				});
			}
		}
	});
	})

})
