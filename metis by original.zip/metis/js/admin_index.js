const checkfields = () => {
  var empty = false

  $(".form-input").each(function(){
    if($(this).val() == ""){
      $(this).css({"border":"1px solid red"})
      empty = true
    }
  })

  return empty
}

const highlight_empty = () => {
  $(".form-input").each(function(){
    $(this).change(function(){
      if($(this).val() == ""){
        $(this).css({"border":"1px solid red"})
      }else{
        $(this).css({"border":"1px solid blue"})
      }
    })
  })
}

const save = (object) => {
  if(!checkfields()){
    $.post("../php/admin_login.php", object, function(result){
      console.log(result)
        var output = JSON.parse(result)
        var status = output["status"]
        var outcome = output["outcome"]

       if(status == true && outcome == "admin"){
            showModal("success", "Admin - Login successfull", "succ52563", function(){
              hideModal()
              window.location.href = "admin.html"
            })
        }else{
          var message = output["outcome"]
          $(".message").text(message)
        }
    })
  }else{
    $(".message").text("Some fields are empty. Enter all the fields to proceed")
  }
}

$(document).ready(function(){
  highlight_empty()

  $(document).on("click", ".login_button", function(e){
    e.preventDefault()

    var user_object = {
      'username' : $(".username").val(),
      'password' : $(".password").val()
    }

    save(user_object)
  })
})
