const checkUser = () => {
  let promise = new Promise((accept, reject = function(){}) => {
    $.post("php/checkUser.php", function(result){
      if(result != ""){
        let output = JSON.parse(result)
        if(output["type"] == "User"){
          user_id = output["user_id"]
          accept(user_id)
        }else{
          showModal("error", "You are not logged in. Please Log in", "erro3783", function(){
            hideModal();
            window.location.href = "index.html"
          })
        }
      }else{
        showModal("error", "You are not logged in. Please Log in", "erro3783", function(){
          hideModal();
          window.location.href = "index.html"
        })
      }

    })
  })
  return promise
}

checkUser().then(function(){
  if("video" in localStorage){
  }else{
    window.location.href = "upload.html"
  }
})

const get_collections = (order) =>{
  $.post("php/get_collections.php", {"order":order}, function(result){
    let output = JSON.parse(result);
    console.log(output)

    for(var i = 0; i < output.length; i++){
      var video_name = output[i][8]
      var name = output[i][2];
      var date_created = output[i].date;
      var database_name = output[i].database_name;

      var html = `
                  <div class="each-element row">
                    <div class="video_cont col-xs-4 col-sm-3 col-md-3 col-lg-3">
                      <video controls class="video_icon">
                        <source src="videos/${database_name}" type="video/mp4">
                      </video>
                    </div>
                    <div class="video_desc col-xs-8 col-sm-9 col-md-9 col-lg-9">
                      <label for="" class="title">${video_name}</label><br />
                      <label for="" class="label submitter_label">Created By: </label><span class="submitter"> ${name}</span><br />
                      <label for="" class="label date">Date Created: </label><span class="date-val"> ${date_created} </span><br />
                      <div class="buttons-cont">
                        <a href="video_preview.html?video=${database_name}"<span class="but_icon fa fa-eye" title="Preview video"></span></a>
                        <span class="but_icon fa fa-link" title="Append video" file="${database_name}"></span>
                        <a href="videos/${database_name}" download><span class="but_icon fa fa-download" title="Download video" file="${database_name}"></span></a>
                        <span class="but_icon fa fa-share-alt" title="Share video" file="${database_name}"></span>
                        <span class="but_icon fa fa-trash" title="Delete video" file="${database_name}"></span>
                      </div>
                    </div>
                  </div>
                `

          $(".create-cont").append(html)
    }

  })
}

const def_function = () => {
  let html = `<video controls class="video">
              <source src="unprocessed/${localStorage["video"]}" type="video/mp4" class="prev_src">
            </video>`
  $(".preview_cont").append(html)
  $(".load-container").hide()
  get_collections("date")
}

$(document).ready(function(){
  def_function()

  $(document).on("click", ".db_upload_submit", function(e){
    e.preventDefault()
    $video_name = $(".db_upload_name").val()
    if($video_name){
        checkUser().then(function(user_id){
          var data = new FormData()
          data.append("user_id", user_id)
          data.append("video_name", $video_name)
          data.append("temp_name", localStorage["video"])

          $.ajax({
      		url: "php/upload_to_server.php",
      		type: "POST",
      		contentType: false,
      		cache: false,
      		processData:false,
      		data: data,
          beforeSend: function(){
              $(".load-container").show()
          },
      		success: function(output){
            $(".load-container").hide()
            console.log(output)
      			if(output){
              showModal("success", "Your video has been uploaded successfully", "sucy762762", function(){
                localStorage['video'] = output
                window.location.href="video_preview.html?video="+output
              })
            }else{
              showModal("error", "There was a problem addid your video to our database", "sucy762762", function(){
                window.location.href="upload.html";
              })
            }
      		}
      	});
      })
    }else{
      $(".db_upload_name").css({"border":"1px solid red"})
    }
  })

  $(document).on("change", ".db_upload_name", function(){
    $(".db_upload_name").css({"border":"1px solid blue"})
  })

  $(document).on("click", ".cancel", function(e){
    e.preventDefault()
    window.location.href = "collections.html"
  })

  $(document).on("click", "", function(e){

  })

  $(document).on("click", ".but_icon", function(e){
    if($(this).attr("title") == "Delete video"){
      $.post("php/delete_video.php", {"database_name":$(this).attr("file")}, function(result){
        if(result){
          showModal("success", "Video Collection deleted successfully", "successs762762", function(){
            window.location.href = "collections.html";
          })
        }else{
          showModal("error", "Unable to delete video collection. please try again", "erere2767626", function(){
            hideModal()
          })
        }
      })
    }else if($(this).attr("title") == "Append video"){
      var video1 = $(this).attr("file")
      checkUser().then(function(user_id){
        var temp_name = localStorage["video"]
        var user_id = user_id

        var data = new FormData()
        data.append("user_id", user_id)
        data.append("video1", video1)
        data.append("temp_name", temp_name)

        $.ajax({
        url: "php/merge.php",
        type: "POST",
        contentType: false,
        cache: false,
        processData:false,
        data: data,
        beforeSend: function(){
            $(".load-container").show()
        },
        success: function(output){
          $(".load-container").hide()
          if(output){
            showModal("success", "Your video has been merged successfully", "aghfs762", function(){
              console.log(output)
              localStorage["video"] = output;
              window.location.href="video_preview.html?video="+output
            })
          }else{
            showModal("error", "Failed merge. Please ensure the name of your video has no special characters", "eersvsjkdj", function(){
              window.location.href="upload.html"
            })
          }
        }
      });
  })
}
})

})
