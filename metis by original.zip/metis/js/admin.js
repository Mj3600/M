const checkfields_create_user = () => {
  var empty = false

  $(".entry_user").each(function(){
    if($(this).val() == ""){
      $(this).css({"border":"1px solid red"})
      empty = true
    }
  })

  return empty
}

function delete_unprocessed(){
  $.post("../php/delete_all.php", function(output){
  })
}

function checkUser(){
  $.post("../php/check_admin_login.php", {}, function(result){
    var result = result;
    if(result === "" || result != "admin"){
      showModal("error", "You must be logged in to access this page", "error567665", function(){
        window.location.href = "index.html"
        hideModal()
      })
    }
  })
}

const highlight_empty_create_user = () => {
  $(".entry_user").each(function(){
    $(this).change(function(){
      if($(this).val() == ""){
        $(this).css({"border":"1px solid red"})
      }else{
        $(this).css({"border":"1px solid blue"})
      }
    })
  })
}

const checkfields_uploads = () => {
  var empty = false

  $(".entry_vid").each(function(){
    if($(this).val() == ""){
      $(this).css({"border":"1px solid red"})
      empty = true
    }
  })

  return empty
}

const highlight_empty_upload = () => {
  $(".entry_vid").each(function(){
    $(this).change(function(){
      if($(this).val() == ""){
        $(this).css({"border":"1px solid red"})
      }else{
        $(this).css({"border":"1px solid blue"})
      }
    })
  })
}

const save_user = (object) => {
  if(!checkfields_create_user()){
    $.post("../php/admin_create_user.php", object, function(result){
        var output = JSON.parse(result)
        var status = output["status"]
        var message = output["output"]

        if(status){
          let passcode = message["passcode"]
          let limit = message["limit"]
          showModal("success", `The passcode ${passcode} has been successfully created with an upload limit of ${limit}`, "bdfdfj3344", function(){
            hideModal();
            $(".passcode").val("")
            $(".max").val("")
            $(".upload_video_tuggle").click();
          })
        }else{
          $(".message").text(message)
          showModal("error", `Error: The passcode already exists`, "error367", function(){
            hideModal();
          })
        }
    })
  }else{
    $(".message").text("Some fields are empty. Enter all the fields to proceed")
  }
}

function display_preview(database_id, title){
  html = `<video class="prev_vid" controls>
            <source class="source" src="videos/${database_id}" type="video/mp4">
          </video>`
  $(".prev-title").text(title);
  $(".vid_cont").empty();
  $(".vid_cont").append(html)
  $(".preview").show()
  $(".progress").hide()
}

function display_merged_preview(database_id, title){
  html = `<video class="prev_vid" controls>
            <source class="source" src="../merged_videos/${database_id}" type="video/mp4">
          </video>`
  $(".prev-title").text(title);
  $(".vid_cont").empty();
  $(".vid_cont").append(html)
  $(".preview").show()
  $(".progress").hide()
}

function display_users_details(){
  $.post("../php/get_all_users.php", {}, function(result){
    $(".table_users").empty()
    let head_html = `<tr>
                      <th>S/N</th>
                      <th>Passcode</th>
                      <th>Name</th>
                      <th>Qualification</th>
                      <th>Clinic</th>
                      <th>Reg date</th>
                      <th>Limit</th>
                      <th>No videos</th>
                      <th>Status</th>
                      <th></th>
                    </tr>`

    let outcome = JSON.parse(result);

    if(outcome.length <= 0){
        $(".table_users").append(`<div class="nothing"> No Users Registered </div>`)
    }else{
        $(".table_users").append(head_html)
          let outcome = JSON.parse(result);
          for(var i = 0; i < outcome.length; i++){
            var user_id = outcome[i].user_id
            var passcode = outcome[i].passcode
            var reg_date = outcome[i].reg_date
            var upload_limit = outcome[i].upload_limit
            var no_uploaded = outcome[i].no_uploaded
            var status = outcome[i].status
            var name = outcome[i].name
            var qualification = outcome[i].qualification
            var speciality = outcome[i].speciality
            var clinic = outcome[i].clinic
            var stripe = (i % 2 == 0) ? "even" : "odd"

            var html = `
                        <tr class='${stripe}'>
                            <td>${user_id}</td>
                            <td>${passcode}</td>
                            <td>${name}</td>
                            <td>${qualification}</td>
                            <td>${clinic}</td>
                            <td>${reg_date}</td>
                            <td>${upload_limit}</td>
                            <td>${no_uploaded}</td>
                            <td>${status}</td>
                            <td><span class="fa fa-trash delete_user" passcode="${passcode}"></td>
                        </tr>
                      `
            $(".table_users").append(html)
          }
      }
  })
}

function display_server_videos(){
  $.post("../php/get_all_server_videos.php", {}, function(result){
    $(".server-videos").empty()
    let head_html = `<tr>
                        <th>S/N</th>
                        <th>Video Title</th>
                        <th>Uploaded for</th>
                        <th>Database_id</th>
                        <th>Date Uploaded</th>
                        <th></th>
                      </tr>`

    let outcome = JSON.parse(result);

    if(outcome.length <= 0){
      $(".server-videos").append(`<div class="nothing"> No Users Registered </div>`)
    }else{
        $(".server-videos").append(head_html)
        for(var i = 0; i < outcome.length; i++){
          var s_no = i + 1
          var passcode = outcome[i].passcode
          var title = outcome[i].title
          var database_id = outcome[i].database_id
          var date = outcome[i].date
          var stripe = (i % 2 == 0) ? "even" : "odd"

          var html = `
                      <tr class='${stripe} user${passcode}'>
                          <td>${s_no}</td>
                          <td>${title}</td>
                          <td>${passcode}</td>
                          <td>${database_id}</td>
                          <td>${date}</td>
                          <td><span class="fa fa-trash delete_server_video" database_id="${database_id}"> </span> <span class="fa fa-eye view_server" database_id='${database_id}'></span></td>

                      </tr>
                    `
          $(".server-videos").append(html)
      }
    }
  })
}

function deleteUser(passcode){
  $.post("../php/delete_user.php", {passcode}, function(result){
    console.log(result)
    if(result){
      showModal("success", "User deleted successfully", "suce7676y27", function(){
        window.location.href = "admin.html";
        hideModal()
      })
    }else{
      showModal("error", "Error deleting user", "error57338", function(){
        hideModal()
      })
    }
  })
}


function display_merged_videos(){
  $.post("../php/get_merged_videos.php", {}, function(result){
    $(".merged-videos").empty()
    let head_html = `<tr>
                        <th>S/N</th>
                        <th>Merger Passcode</th>
                        <th>Database_id</th>
                        <th>Date Uploaded</th>
                        <th>Expiry Date</th>
                        <th></th>
                    </tr>`

    let outcome = JSON.parse(result);

    if(outcome.length <= 0){
      $(".merged-videos").append(`<div class="nothing"> No Merged video in database </div>`)
    }else{
        $(".merged-videos").append(head_html)
        for(var i = 0; i < outcome.length; i++){
          var s_no = i + 1
          var passcode = outcome[i].passcode
          var database_id = outcome[i].database_id
          var upload_date = outcome[i].date_uploaded
          var expiry_date = outcome[i].expiry_date
          var stripe = (i % 2 == 0) ? "even" : "odd"

          var html = `
                      <tr class='${stripe}'>
                          <td>${s_no}</td>
                          <td>${passcode}</td>
                          <td>${database_id}</td>
                          <td>${upload_date}</td>
                          <td>${expiry_date}</td>
                          <td><span class="fa fa-trash delete_merged" database_id=${database_id}> </span> <span class="fa fa-eye view_merged" database_id=${database_id} passcode=${passcode}></span></td>
                      </tr>
                    `
          $(".merged-videos").append(html)
      }
    }
  })
}

function deleteMergedVideo(database_id){
  $.post("../php/delete_merged_video.php", {database_id}, function(result){
    if(result){
      showModal("success", "Merged Video Deleted Successfully", "763gsghs", function(){
        window.location.href = "admin.html";
        hideModal()
      })
    }else{
      showModal("error", "Error deleting merged video", "6fgfgfg76376434", function(){
        hideModal()
      })
    }
  })
}

function deleteServerVideo(database_id){
  $.post("../php/delete_server_video.php", {database_id}, function(result){
    if(result){
      showModal("success", "Server Video Deleted Successfully", "763gsghs", function(){
        window.location.href = "admin.html";
        hideModal()
      })
    }else{
      showModal("error", "Error deleting Server video", "6fgfgfg76376434", function(){
        hideModal()
      })
    }
  })
}

function def(){
  delete_unprocessed()

  $(".create_user_tuggle").addClass("active");
  $(".upload_video").hide()

  $(".user-logs").addClass("active");
  $(".server-videos-cont").hide()
  $(".merged-videos-cont").hide()
  $(".tuggle-header").text("Users Logs")

  $(".progress-bar").hide()
  $(".preview").hide()
}

checkUser()

$(document).ready(function(){
  def()
  highlight_empty_create_user()
  highlight_empty_upload()

  $(document).on("click", ".create_tuggle", function(){
    if($(this).hasClass("create_user_tuggle")){
      $(".upload_video").hide()
      $(".create_user").slideDown(1000)
      $(".upload_video_tuggle").removeClass("active")
      $(".create_user_tuggle").addClass("active")
    }else if($(this).hasClass("upload_video_tuggle")){
      $(".create_user").hide()
      $(".upload_video").slideDown(1000)
      $(".create_user_tuggle").removeClass("active")
      $(".upload_video_tuggle").addClass("active")
    }
  })

  $(document).on("click", ".tuggle-buttons", function(){
    if($(this).hasClass("user-logs")){
      $(".user-logs").siblings().removeClass("active");
      $(".user-logs").addClass("active");
      $(".server-videos-cont").hide()
      $(".merged-videos-cont").hide()
      $(".tuggle-header").text("Users Logs")
      $(".user-log-cont").show()
      display_users_details()
    }else if($(this).hasClass("server-vid")){
      $(".server-vid").siblings().removeClass("active");
      $(".server-vid").addClass("active");
      $(".user-log-cont").hide()
      $(".merged-videos-cont").hide()
      $(".tuggle-header").text("Server Videos")
      $(".server-videos-cont").show()
      display_server_videos()
    }else if($(this).hasClass("merged-vid")){
      $(".merged-vid").siblings().removeClass("active");
      $(".merged-vid").addClass("active");
      $(".user-log-cont").hide()
      $(".tuggle-header").text("Merged Videos")
      $(".server-videos-cont").hide()
      $(".merged-videos-cont").show()
      display_merged_videos()
    }
  })

  $(document).on("click", ".close-preview", function(){
    $(".preview").hide()
    $(".title").val("")
    $(".passcode").val("")
    $(".video_entry").val("")
  })

  $(document).on("click", ".create-button", function(e){
    e.preventDefault()

    let passcode = $(".passcode").val()
    let limit = $(".max").val()

    save_user({passcode, limit})
  })

  $(document).on("click", ".select", function(){
    $(".video_file").click()
	})

  $(document).on("click", ".close-preview", function(){
    $(".preview.hide").click()
	})

  $(document).on("change", ".video_file", function(){
    let val = $(".video_file").val()
    $(".video_entry").val(val)
	})

  $(document).on("click", ".delete_user", function(){
    let passcode = $(this).attr("passcode");
    deleteUser(passcode);
  })

  $(document).on("click", ".delete_merged", function(){
    let database_id = $(this).attr("database_id");
    console.log(database_id);
    deleteMergedVideo(database_id);
  })

  $(document).on("click", ".delete_server_video", function(){
    let database_id = $(this).attr("database_id");
    deleteServerVideo(database_id);
  })

  $(document).on("click", ".view_merged", function(){
    let database_id = $(this).attr("database_id");
    let passcode = $(this).attr("passcode");
    display_merged_preview(database_id, passcode)
  })

  $(document).on("click", ".view_server", function(){
    let database_id = $(this).attr("database_id");
    let passcode = $(this).attr("passcode");
    display_preview(database_id, passcode)
  })

  $(document).on("submit", ".upload_video", function(e){
		e.preventDefault();

    if(!checkfields_uploads()){
      		$.ajax({
          xhr: function(){
            var xhr = new window.XMLHttpRequest();
            xhr.upload.addEventListener("progress", function(evt){
              if(evt.lengthComputable){
                var percentComplete = (evt.loaded / evt.total) * 100
                $(".progress").css({"width":percentComplete+"%"})
                $(".progress-text").text(Math.floor(percentComplete)+"%")
              }
            }, false)
            return xhr
          },
      		url: "../php/admin_upload_video.php",
      		type: "POST",
      		contentType: false,
      		cache: false,
      		processData:false,
      		data: new FormData(this),
          beforeSend: function(){
              $(".progress-bar").show()
          },
      		success: function(output){
        			console.log(output)
        			var result = JSON.parse(output);
        			var status = result.status;
        			var message = result.output;

        			if(status == "1"){
                showModal("success", "The video uploaded successfully", "shsdhj7373", function(){
                  hideModal()
                  $(".progress-bar").hide();
                })

        			}else{
        				showModal("error", message, "uploadFileError566776", function(){
        					hideModal();
        					$(".entry_vid").val = "";
                  $(".progress-bar").hide();
        				});
        			}
        		}
        	});
      }else{
        $(".upload_message").text("Missing fields. Please complete all fields and try again")
      }
	})
})
