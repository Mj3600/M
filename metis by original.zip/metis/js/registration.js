const checkUser = () => {
  let promise = new Promise((accept, reject = function(){}) => {
    $.post("php/checkUser.php", function(result){
      if(result != ""){
        let passcode = result
        accept(passcode)
      }else{
        showModal("error", "You are not logged in. Please Log in", "erro3783", function(){
          hideModal();
          window.location.href = "index.html"
        })
      }
    })
  })
  return promise
}

checkUser().then(function(){

})

const checkfields = () => {
  var empty = false

  $(".form-input").each(function(){
    if($(this).val() == ""){
      $(this).css({"border":"1px solid red"})
      empty = true
    }
  })

  return empty
}

const highlight_empty = () => {
  $(".form-input").each(function(){
    $(this).change(function(){
      if($(this).val() == ""){
        $(this).css({"border":"1px solid red"})
      }else{
        $(this).css({"border":"1px solid blue"})
      }
    })
  })
}

const save = (object) => {
  if(!checkfields()){
    $.post("php/register.php", object, function(result){
      if(result){
        window.location.href = "upload.html"
      }else{
        $(".message").text("The registration failed")
      }
    })
  }else{
    $(".message").text("Some fields are empty. Enter all the fields to proceed")
  }
}



$(document).ready(function(){
  highlight_empty()

  $(document).on("click", ".login_button", function(e){
    e.preventDefault()

    checkUser().then(function(passcode){
      var user_object = {
        'name' : $(".name").val(),
        'speciality' : $(".speciality").val(),
        'qualification' : $(".qualification").val(),
        'clinic_name' : $(".clinic_name").val(),
        'passcode' : passcode
      }
        save(user_object)
    })

  })
})
