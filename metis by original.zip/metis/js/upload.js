const checkUser = () => {
  let promise = new Promise((accept, reject = function(){}) => {
    $.post("php/checkUser.php", function(result){
      if(result != ""){
        let passcode = result
        accept(passcode)
      }else{
        showModal("error", "You are not logged in. Please Log in", "erro3783", function(){
          hideModal();
          window.location.href = "index.html"
        })
      }
    })
  })
  return promise
}

checkUser().then(function(){

})

const get_server_video = (passcode) =>{
  $.post("php/get_server_video.php", {passcode}, function(result){
    let output = JSON.parse(result);

    for(var i = 0; i < output.length; i++){
      var video_name = output[i].title
      var date_created = output[i].date;
      var database_id = output[i].database_id;

      var html = `
                  <div class="each-element row">
                    <div class="video_cont col-xs-12 col-sm-12 col-md-12 col-lg-12">
                      <video controls class="video_icon">
                        <source src="admin/videos/${database_id}" type="video/mp4">
                      </video>
                    </div>
                    <div class="video_desc col-xs-12 col-sm-12 col-md-12 col-lg-12">
                      <div>
                        <label for="" class="title">${video_name}</label><br />
                        <label for="" class="label_date">Date Created: </label><span class="date-val"> ${date_created} </span><br />
                      </div>
                      <div class="buttons-cont">
                        <span class="but_icon fa fa-link merged_video" title="Append video" file=${database_id}> Append </span>
                      </div>
                    </div>
                  </div>
                `

          $(".server_video_container").append(html)
    }
  })
}


const default_function = () => {
  $(".prev_video").hide()
  $(".done").hide()
  $(".progress-bar").hide()
  $(".load-container").hide()

  checkUser().then(function(passcode){
    get_server_video(passcode)
  })

}

const display_preview = () => {
  $(".prev_video").show()
  $(".done").show()
  $(".input").hide()
  $(".record").hide()
}

$(document).ready(function(){
  default_function()

  $(document).on('click', '.select_video', function(e){
    e.preventDefault()
    $(".video_file").click()
  })

  $(document).on('click', '.record_video', function(e){
    e.preventDefault()
    window.location.href="record.html"
  })

  $(document).on("click", ".cancel", function(e){
    e.preventDefault()
    window.location.href = "upload.html"
  })

  $(document).on("change", ".video_file", function(){
    let val = $(".video_file").val()
    $(".video_name").val(val)
    $(".record").hide()
    $(".progress-bar").show()
    $(".select_video").attr("disabled", "disabled")
		$(".submit_file").click();
	})

  $(document).on('click', '.merged_video', function(e){
    $(window).scrollTop(0)
    let video1 = $(this).attr("file")
    let video2 = $(".source").attr("title") != ""?$(".source").attr("title"): ""
    checkUser().then(function(passcode){
      if(video2){
        var data = new FormData()
        data.append("passcode", passcode)
        data.append("video1", video1)
        data.append("temp_name", video2)

        $.ajax({
        url: "php/merge.php",
        type: "POST",
        contentType: false,
        cache: false,
        processData:false,
        data: data,
        beforeSend: function(){
            $(".load-container").show()
        },
        success: function(output){
          output = JSON.parse(output)
          $(".load-container").hide()

          if(output["status"]){
            showModal("success", "Your video has been merged successfully", "aghfs762", function(){

              localStorage["video"] = output;
              window.location.href="video_preview.html?video="+output["output"]
            })
          }else{
            showModal("error", "Failed merge."+output["output"], "eersvsjkdj", function(){
              window.location.href="upload.html"
            })
          }
        }
      });
      }else{
        showModal("error", "No video uploaded. please upload a video before appending", "eroor7744", function(){
          hideModal()
        })
      }
    })
  })

  $(document).on("submit", ".upload_video", function(e){
		e.preventDefault();

		$.ajax({
    xhr: function(){
      var xhr = new window.XMLHttpRequest();
      xhr.upload.addEventListener("progress", function(evt){
        if(evt.lengthComputable){
          var percentComplete = (evt.loaded / evt.total) * 100
          $(".progress").css({"width":percentComplete+"%"})
          $(".progress-text").text(Math.floor(percentComplete)+"%")
        }
      }, false)
      return xhr
    },
		url: "php/upload_raw.php",
		type: "POST",
		contentType: false,
		cache: false,
		processData:false,
		data: new FormData(this),
		success: function(output){
			var result = JSON.parse(output);
			var status = result.status;
			var message = result.result;

			if(status == "1"){
        display_preview()
        let html = `<video class="prev_video" controls>
                      <source class="source" src="unprocessed/${message}" title=${message} type="video/mp4">
                    </video>`
				$(".preview").append(html);

			}else{
				showModal("error", message, "uploadFileError", function(){
					hideModal();
					$(".video_name").val = "";
          $(".progress-bar").hide();
				});
			}
		}
	});
	})

})
