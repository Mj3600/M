const checkUser = () => {
  let promise = new Promise((accept, reject = function(){}) => {
    $.post("php/checkUser.php", function(result){
      if(result != ""){
        let output = JSON.parse(result)
        if(output["type"] == "Admin"){
          user_id = output["user_id"]
          accept(user_id)
        }else{
          showModal("error", "You are not logged in. Please Log in", "erro3783", function(){
            hideModal();
            window.location.href = "index.html"
          })
        }
      }else{
        showModal("error", "You are not logged in. Please Log in", "erro3783", function(){
          hideModal();
          window.location.href = "index.html"
        })
      }

    })
  })
  return promise
}

checkUser().then(function(){

})

const checkfields = () => {
  var empty = false

  $(".form-input").each(function(){
    if($(this).val() == ""){
      $(this).css({"border":"1px solid red"})
      empty = true
    }
  })

  return empty
}

const highlight_empty = () => {
  $(".form-input").each(function(){
    $(this).change(function(){
      if($(this).val() == ""){
        $(this).css({"border":"1px solid red"})
      }else{
        $(this).css({"border":"1px solid blue"})
      }
    })
  })
}

const save = (object) => {
  if(!checkfields()){
    $.post("php/createUser.php", object, function(result){
        if(result){
          outcome = JSON.parse(result)
            showModal("success", `New User Created (Username: ${outcome["username"]} - Password: ${outcome["password"]})`, "succ52563", function(){
              hideModal()
              window.location.href = "createUser.html"
            })
          }else{
            showModal("error", "There is a problem creating User", "error344222", function(){
              hideModal()
              window.location.href = "createUser.html"
            })
          }
    })
  }else{
    $(".message").text("Some fields are empty. Enter all the fields to proceed")
  }
}

$(document).ready(function(){
  highlight_empty()

  $(document).on("click", ".login_button", function(e){
    e.preventDefault()

    var user_object = {
      'username' : $(".username").val(),
      'password' : $(".password").val()
    }

    save(user_object)
  })
})
