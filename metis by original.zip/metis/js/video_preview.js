function getQueries(address){
	var url = address;
	var queryStrings = (url.slice(url.indexOf("?") + 1)).split("&");
	var queries = [];
	for(i in queryStrings){
		var queryName = queryStrings[i].split("=")[0];
		var queryValue = queryStrings[i].split("=")[1];
		var newArray = [queryName, queryValue];
		queries.push(newArray);
	}
	return(queries);
}

function getEventId(address){
	var id = "";
	var queries = getQueries(address);
	for(i in queries){
		if(queries[i][0] == "video"){
			id = queries[i][1];
		}
	}
	return id;
}


function checkVideo(video){
    $.post("php/check_video.php", {video}, function(result){
			if(result){

			}else{
				reject();
			}
    })
}

function reject(){
  showModal("error", "Invalid video address specified", "error7627878", function(){
    window.location.href="upload.html";
    hideModal()
  })
}

/**********************IMPLEMENTING FUNCTIONS ********************************************************/
checkVideo(getEventId(window.location.href));

function def(){
	var video = getEventId(window.location.href)
	html = `<video src="merged_videos/${video}" autoplay controls></video>`
	$(".video-cont").append(html)

	display_share_link()

	$(".download-link").attr("href", "merged_videos/"+video)
}

function display_details(){
	video = getEventId(window.location.href)
	$.post("php/get_video.php", {video}, function(output){
		console.log(output)
		var result = JSON.parse(output)
		var video_name = result.database_id
		var name = `${result.name} ( ${result.qualification})`
		var date = result.date_uploaded

		$(".prev_name").text(video_name)
		$(".created_by").text(name)
		$(".date_created").text(date)
	})
}

function display_share_link(){
	var video = getEventId(window.location.href)
	html = `<div class="icon_cont download-cont">
						<a href='merged_videos/${video}' class="save_button" download><span class="fa fa-download save_down"></span><span class="save-text"> Save </span> </a>
					</div>
					<div class="icon_cont">
						<a href="whatsapp://send?text=${window.location.href}" data-action="share/whatsapp/share" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Share on whatsapp"><img class="share_icon" src="images/watsapp.jpg"></a>
					</div>
					<div class="icon_cont">
						<a href="https://www.facebook.com/sharer/sharer.php?u=${window.location.href}&t=METIS: VIDEO DOWNLOAD" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Share on Facebook"><img class="share_icon" src="images/facebook.jpg"></a>
					</div>
					<div class="icon_cont">
						<a href="https://www.linkedin.com/shareArticle?mini=true&url=${window.location.href}&t=METIS VIDEO DOWNLOAD" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Share on Linkedin"><img class="share_icon" src="images/in.png"></a>
					</div>
					<div class="icon_cont">
						<a href="mailto:?subject=[METIS: VIDEO DOWNLOAD]&body=${window.location.href}" class="mail-link" onClick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=300,width=600');return false;" target="_blank" title="Share on Mail"><img class="share_icon email_icon" src="images/email.jpg"></a>
					</div>`
	$(".share_icons-cont").append(html)
}

$(document).ready(function(){
	def()
	display_details()
})
