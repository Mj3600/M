checkUser().then(function(){

})

function hasUserMedia(){
  return !! (navigator.mediaDevices && navigator.mediaDevices.getUserMedia)
}

function timer(){
  min = 0
  sec = 0
  status = 0

  let time = setInterval(function(){
    $(".start").click(function(e){
      e.preventDefault()
        status = 1
        $(".status_icon").removeClass("fa-pause")
        $(".status_icon").removeClass("fa-circle")
        $(".status_icon").addClass("fa-circle")
    })

    $(".pause").click(function(e){
      e.preventDefault()
      $(".status_icon").removeClass("fa-circle")
      $(".status_icon").addClass("fa-pause")
        status = 0
    })

    $(".resume").click(function(e){
      e.preventDefault()
        status = 1
        $(".status_icon").removeClass("fa-pause")
        $(".status_icon").addClass("fa-circle")
    })

    $(".stop").click(function(e){
      e.preventDefault()
      status = 0
      $(".firstBtn").hide()
      $(".firstBtn").attr("disabled", "disabled")
      $(".status_icon").removeClass("fa-pause")
      $(".status_icon").addClass("fa-circle")
      $(".preview-but").show()
    })

    $(".preview").click(function(e){
      e.preventDefault()
      status = 0
      $(".controls").remove()
    })

    $(".save").click(function(e){
      e.preventDefault()
      $(".progress-bar").show()
      status = 0
      sec = 0
      min = 0
    })



    if(status == 1){
      if(sec >= 59){
        min = min + 1
        sec = 0
      }else{
        sec = sec + 1
      }

      secString = ""+sec
      minString = ""+min

      if(secString.length < 2){
        for_sec = "0"+ sec
      }else{
        for_sec = sec
      }

      if(minString.length < 2){
        for_min = "0"+ min
      }else{
        for_min = min
      }

      $(".time").fadeOut(500)
      $(".time").text(`${for_min}:${for_sec}`)
      $(".time").fadeIn(500)
    }
  }, 1000)
}

function preview_vid(video){
  $(".counter").hide()
  $(".controls").hide()

  let html = `<video class="prev_video" controls>
                <source class="source" src="unprocessed/${video}" title=${message} type="video/mp4">
              </video>`
  $(".video").append(html);
}

function default_funct(){
  $(".firstBtn").hide();
  $(".start").show()
  $(".done").hide()
  $(".progress-bar").hide()
  $(".preview-but").hide()
  timer()

  if(hasUserMedia){
    let constraint = {
      video: true,
      audio: true
    }

    let video = document.querySelector(".video")

    navigator.mediaDevices.getUserMedia(constraint).then((stream) => {
      video.srcObject = stream

      var recordedChuncks = []

      options = {
        mimeType: "video/webm"
      }

      recorder = new MediaRecorder(stream, options)

      startb = document.querySelector(".start")
      stopb = document.querySelector(".stop")
      pauseb = document.querySelector(".pause")
      resumeb = document.querySelector(".resume")

      startb.addEventListener("click", function(){
        console.log("start recording")
        recorder.start()
      })

      stopb.addEventListener("click", function(e){
        e.preventDefault()
        console.log("stop recording")
        recorder.stop()
      })

      pauseb.addEventListener("click", function(){
        console.log("pause")
        recorder.pause()
      })

      resumeb.addEventListener("click", function(){
        console.log("Resume")
        recorder.resume()
      })

      recorder.ondataavailable = handleDataAvailable

      function handleDataAvailable(event){
          if(event.data.size > 0){
            recordedChuncks.push(event.data)
            console.log(recordedChuncks)
            var mp4 = new Blob(recordedChuncks, {type:"video/mp4"})
            formData = new FormData()
            formData.append('video_file', mp4, "record.mp4")

            $(document).on("click", ".preview-but", function(e){
              e.preventDefault();
            		$.ajax({
                xhr: function(){
                  var xhr = new window.XMLHttpRequest();
                  xhr.upload.addEventListener("progress", function(evt){
                    if(evt.lengthComputable){
                      var percentComplete = (evt.loaded / evt.total) * 100
                      $(".progress").css({"width":percentComplete+"%"})
                      $(".progress-text").text(Math.floor(percentComplete)+"%")
                    }
                  }, false)
                  return xhr
                },
            		url: "php/upload_raw.php",
            		type: "POST",
            		contentType: false,
            		cache: false,
            		processData:false,
            		data: formData,
            		success: function(output){
                  console.log(output)
            			var result = JSON.parse(output);
            			var status = result.status;
            			var message = result.result;

            			if(status == "1"){
                    let html = `<video class="prev_video" controls>
                                  <source class="source" src="unprocessed/${message}" title=${message} type="video/mp4">
                                </video>`
            				$(".preview").append(html);
                    $(".video").hide();
                    $(".controls").hide();
                    $(".counter").hide();

            			}else{
            				showModal("error", message, "uploadFileError", function(){
            					hideModal();
            					$(".video_name").val = "";
                      $(".progress-bar").hide();
            				});
            			}
            		}
            	});
            	})
    }else{
        console.log("unavailable")
    }
}
})

}else{
  console.log("unavailable")
}
}

$(document).ready(function(){
  default_funct()

  $(document).on("click", ".firstBtn", function(e){
    e.preventDefault()
    if($(this).hasClass("start")){
      $(".firstBtn").hide();
      $(".pause").show()

    }else if($(this).hasClass("pause")){
      $(".firstBtn").hide();
      $(".resume").show()

    }else if($(this).hasClass("resume")){
      $(".firstBtn").hide();
      $(".pause").show()
    }
  })
})
